BD PLAY GAME website package

Files:
- index.html: website homepage
- bd_play_game.apk: your uploaded Android app
- bd-play-game-logo.jpg: logo image (if supplied)

How to publish:
1. Extract this ZIP.
2. Upload ALL files into the same public/root folder of your hosting service.
3. Make sure the APK filename remains exactly: bd_play_game.apk
4. Open your website URL and test the Download Now button.

Important:
The APK is downloaded from the same hosting folder as index.html.
If you upload only index.html, the download button cannot find the APK.
